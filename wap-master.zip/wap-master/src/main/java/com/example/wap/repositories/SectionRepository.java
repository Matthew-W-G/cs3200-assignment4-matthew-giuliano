package com.example.wap.repositories;

import com.example.wap.models.Section;
import org.springframework.data.repository.CrudRepository;

public interface SectionRepository
    extends CrudRepository<Section, Integer> {
}
